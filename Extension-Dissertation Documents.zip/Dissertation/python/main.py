from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, roc_curve, auc, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import numpy as np
# import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import sys
import time

# getData will already split data and give func the train stuff. 

def getData():
	# print('--------------1--------------------')
	dataset = pd.read_csv('Data/Training_Dataset_NoID.csv')
	# dataset = dataset.drop('id',1)
	print('---------------2-------------------')

	print('The dataset has {0} datapoints with {1} features'.format(
		dataset.shape[0], dataset.shape[1]-1))
	# nums = [0,1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,22,30]	# dnot = [8,17,18,19,20,21,23,24,25,26,27,28,29] print(dataset.columns)
	# print('These will be the final features selected for this task')
	# for i in nums:#   print (dataset.columns[i])
	# print('----------------3------------------')

	dataset = dataset.drop(columns=['Domain_registeration_length', 'Abnormal_URL', 'Redirect', 'on_mouseover', 'RightClick',
                                 'popUpWidnow', 'age_of_domain', 'DNSRecord', 'web_traffic', 'Page_Rank', 'Google_Index', 'Links_pointing_to_page', 'Statistical_report'])
	
	x = dataset.drop(['Result'], axis=1).values
	y = dataset['Result'].values  # print(y.shape)
	

	# Need to grab the features for the weights output.

	dataset = dataset.drop(columns = ['Result'])
	# print('---------------------8-------------')

	# print(dataset.columns)
	from sklearn.model_selection import train_test_split
	x_train, x_test, y_train, y_test = train_test_split(
		x, y, test_size=0.30)  # print(x_train.shape)

	return x_train, x_test, y_train, y_test,dataset


def random_forest(x_train,x_test,y_train,y_test,dataset):
	start= time.time()
	RFC = RandomForestClassifier(
		n_estimators=700, criterion='gini', max_features='sqrt', random_state=0)
	RFC = RFC.fit(x_train, np.ravel(y_train, order='C')) #Was getting a warning with just( RFC.fit(x_train,y_train)) and this is how to clear it up.
	feature_importances = pd.DataFrame(RFC.feature_importances_, index=dataset.columns, columns=['importance']).sort_values('importance', ascending=False)
	# print(feature_importances)
	prediction = RFC.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log

def logistic_regression(x_train,x_test,y_train,y_test):
	#2) Logistic Regresison
	start = time.time()
	from sklearn.linear_model import LogisticRegression
	logreg = LogisticRegression(solver='lbfgs')
	logreg = logreg.fit(x_train, np.ravel(y_train, order='C'))
	prediction = logreg.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log

def svmlinear(x_train,x_test,y_train,y_test):
	# 3)SVM-Linear
	#3 Classification using SVM
	start = time.time()
	svc_l = SVC(kernel="linear", C=0.025)
	svc_l = svc_l.fit(x_train, np.ravel(y_train, order='C'))
	prediction = svc_l.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log



def svmNoLinear(x_train,x_test,y_train,y_test):
	# 3.a SVM No-linear
	start = time.time()
	svc_l = SVC(C=1000, kernel='rbf', gamma=0.2, random_state=0)
	svc_l = svc_l.fit(x_train, np.ravel(y_train, order='C'))
	
	# print(x_train.columns)

	prediction = svc_l.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log

def decisionTree(x_train,x_test,y_train,y_test):
	# 4)Decision Tree
	start = time.time()
	DT = tree.DecisionTreeClassifier()
	DT.fit(x_train, np.ravel(y_train, order='C'))
	prediction = DT.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log


def K_nn(x_train,x_test,y_train,y_test):

	# 5) K-NN
	start = time.time()
	Knn = KNeighborsClassifier(n_neighbors=3)
	Knn.fit(x_train, np.ravel(y_train, order='C'))
	prediction = Knn.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log

def Naivebayes(x_train,x_test,y_train,y_test):
	start = time.time()
	# 6) Naive Bayes
	NB = GaussianNB()
	NB.fit(x_train, np.ravel(y_train, order='C'))
	prediction = NB.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log

def DeepNN(x_train,x_test,y_train,y_test):
	# 7) DNN
	start = time.time()
	DNN = MLPClassifier(solver='lbfgs', alpha=1e-5,
				hidden_layer_sizes=(15,), random_state=1)
	DNN.fit(x_train, np.ravel(y_train, order='C'))
	prediction = DNN.predict(x_test)
	accuracy = 100.0 * accuracy_score(y_test, prediction)
	end = time.time()
	Log = str(end-start)
	return accuracy, Log




def main():
	# import warnings
	# warnings.filterwarnings("ignore")
	x_train, x_test, y_train, y_test,dataset = getData()
	# print(dataset.columns)
	# print('sssssssss')
	print ("\nrunning random forests...") #***Fastest
	Acc, time = random_forest(x_train, x_test, y_train, y_test,dataset)
	print('Accuracy: ',Acc, '\nRuntime: ',time)

	# print("\nrunning logistic Regression...")
	# Acc, time = logistic_regression(x_train, x_test, y_train, y_test)
	# print('Accuracy: ', Acc, '\nRuntime: ', time)

	# print("\nrunning svmLinear...")
	# Acc, time = svmlinear(x_train, x_test, y_train, y_test)
	# print('Accuracy: ', Acc, '\nRuntime: ', time)

	print("\nrunning svmNoLinear...")
	Acc, time = svmNoLinear(x_train, x_test, y_train, y_test)
	print('Accuracy: ', Acc, '\nRuntime: ', time)

	print("\nrunning Decision Tree...")
	Acc, time = decisionTree(x_train, x_test, y_train, y_test)
	print('Accuracy: ', Acc, '\nRuntime: ', time)

	# print("\nrunning K-NN...")
	# Acc, time = K_nn(x_train, x_test, y_train, y_test)
	# print('Accuracy: ', Acc, '\nRuntime: ', time)

	# print("\nrunning Naive Bayes...") #57% acc
	# Acc, time = Naivebayes(x_train, x_test, y_train, y_test)
	# print('Accuracy: ', Acc, '\nRuntime: ', time)

	print("\nrunning Neural Network...")
	Acc, time = DeepNN(x_train, x_test, y_train, y_test)
	print('Accuracy: ', Acc, '\nRuntime: ', time)


if __name__ == '__main__':
	start = time.time()
	main()
	end = time.time()

	print('Overall Runtime: ',str(end-start))
